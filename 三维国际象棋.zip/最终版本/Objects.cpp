// Objects.cpp
#include <cmath>
#include <vector>
#include "ChessBoard.h"
#include "Objects.h"

// ����ͨ�û���
void drawBase() {
    glPushMatrix();
        glColor3f(0.75f, 0.75f, 0.75f);
        glTranslatef(0.0f, -0.5f, 0.0f);
        glRotatef(-90, 1, 0, 0);
        glutSolidCylinder(0.4f, 0.1f, 8, 2);
    glPopMatrix();
}

// ��
class Pawn : public ChessPiece {
public:
    using ChessPiece::ChessPiece;
    
    PieceType getType() const override { return PAWN; }
    
    void drawSimple() const override {
    	// ���õ�ǰ���ӵ�id
    	glLoadName(id);
    	
			// ����
            glPushMatrix();
		    	glColor3f(0.75f, 0.75f, 0.75f);
			    glTranslatef(0.0f, -0.5f, 0.0f);
			    glRotatef(-90, 1, 0, 0);
			    glutSolidCylinder(0.3f, 0.1f, 8, 2); // �߶���Y��
			    applyMaterial();
	    	glPopMatrix();

            // ����
            glPushMatrix();
                glTranslatef(0.0f, -0.4f, 0.0f);
                glRotatef(-90, 1, 0, 0);
                glutSolidCylinder(0.15f, 0.6f, 20, 20);
            glPopMatrix();

            // ����������
            glPushMatrix();
                glTranslatef(0.0f, 0.2f, 0.0f);
                glutSolidSphere(0.2f, 20, 20);
            glPopMatrix();
	}

    void draw() const override {
        glPushMatrix();
            transformPosition();
			
            drawSimple();
            
            // ����С����
		    glPushMatrix();
		    	glColor3f(0.75f, 0.75f, 0.75f);
			    glTranslatef(0.0f, 0.425f, 0.0f); // ����ײ�λ��Բ������
			    glutSolidSphere(0.05f, 20, 20);
			    applyMaterial();
		    glPopMatrix();

        glPopMatrix();
    }
};

// ��
class Rook : public ChessPiece {
public:
    using ChessPiece::ChessPiece;
    
    PieceType getType() const override { return ROOK; }
    
    void drawSimple() const override {
		// ���õ�ǰ���ӵ�id
    	glLoadName(id);
    	
    		// ����
            drawBase();
            applyMaterial();

            // ����
            glPushMatrix();
                glScalef(0.4f, 0.8f, 0.4f);
                glutSolidCube(1.0f);
            glPopMatrix();

            // ����Բ��
			glPushMatrix();
			glColor3f(0.75f, 0.75f, 0.75f);
			    glTranslatef(0.0f, 0.4f, 0.0f);
			    glRotatef(-90, 1, 0, 0);
			    glutSolidCylinder(0.3f, 0.1f, 8, 2); // �߶���Y��
			    applyMaterial();
		    glPopMatrix();
	}

    void draw() const override {
        glPushMatrix();
            transformPosition();
            
            drawSimple();

            // �Ƕ�
            const float positions[4][2] = {{0.2f,0.0f}, {0.0f,0.2f}, {-0.2f,0.0f}, {0.0f,-0.2f}};
            for(auto& pos : positions) {
                glPushMatrix();
                    glTranslatef(pos[0], 0.55f, pos[1]);
                    glScalef(0.1f, 0.2f, 0.1f);
                    glutSolidCube(1.0f);
                glPopMatrix();
            }
        glPopMatrix();
    }
};

// ��
class Knight : public ChessPiece {
public:
    using ChessPiece::ChessPiece;
    
    PieceType getType() const override { return KNIGHT; }
    
    void drawSimple() const override {
		// ���õ�ǰ���ӵ�id
    	glLoadName(id);

			// ����
            drawBase();
            applyMaterial();

            // ����
            glPushMatrix();
                glTranslatef(0.0f, 0.1f, 0.0f);
                glScalef(0.35f, 1.0f, 0.3f);
                glutSolidCube(1.0f);
            glPopMatrix();

            // ͷ��
            glPushMatrix();
                if(white) glRotatef(180, 0, 1, 0);
                glTranslatef(0.0f, 0.2f, -0.3f);
                glRotatef(30, 1, 0, 0);
                glTranslatef(0.0f, 0.4f, 0.0f);  // ƫ���γɾ�������
                glutSolidCylinder(0.13f, 0.55f, 20, 20);
            glPopMatrix();
	}

    void draw() const override {
        glPushMatrix();
            transformPosition();
            
            drawSimple();
            
            // ���䣨˫׶�壩
	        glColor3f(0.5451f, 0.2706f, 0.0745f);
	        glPushMatrix();
	            glTranslatef(-0.1f, 0.6f, 0.0f);
	            glRotatef(-90, 1, 0, 0);
	            glutSolidCone(0.05f, 0.15f, 10, 10);
	        glPopMatrix();

	        glPushMatrix();
	            glTranslatef(0.1f, 0.6f, 0.0f);
	            glRotatef(-90, 1, 0, 0);
	            glutSolidCone(0.05f, 0.15f, 10, 10);
	        glPopMatrix();

        	// ��ëװ��
	        glPushMatrix();
	            white ? glTranslatef(0.0f, 0.225f, 0.08f) : glTranslatef(0.0f, 0.225f, -0.08f);
	            white ? glRotatef(90, 0, 1, 0) : glRotatef(-90, 0, 1, 0);
	            glRotatef(-10, 0, 0, 1);
	            glScalef(0.3f, 0.45f, -0.1f);
	            glutSolidCube(1.0f);
	        glPopMatrix();
	        applyMaterial();

        glPopMatrix();
    }
};

// ��
class Bishop : public ChessPiece {
public:
    using ChessPiece::ChessPiece;
    
    PieceType getType() const override { return BISHOP; }
    
    void drawSimple() const override {
		// ���õ�ǰ���ӵ�id
    	glLoadName(id);

			// ����
            drawBase();
            applyMaterial();

			// ����
            glPushMatrix();
		    	glTranslatef(0.0f, -0.4f, 0.0f);
			    glRotatef(-90, 1, 0, 0);
			    glutSolidCone(0.25f, 1.2f, 20, 20); // �ײ�Y=0������Y=0.8
		    glPopMatrix();
		    
		    // ����������
		    glPushMatrix();
			    glTranslatef(0.0f, 0.8f, 0.0f);
			    glutSolidSphere(0.2f, 20, 20);
		    glPopMatrix();
	}

    void draw() const override {
        glPushMatrix();
            transformPosition();
            
            drawSimple();

			// �徱
		    glPushMatrix();
		  		glColor3f(0.75f, 0.75f, 0.75f);
			    glTranslatef(0.0f, 0.5f, 0.0f);
			    glRotatef(-90, 1, 0, 0);
			    glutSolidCylinder(0.3f, 0.1f, 8, 2); // �߶���Y��
			    applyMaterial();
		    glPopMatrix();

		    // ����С����
		    glPushMatrix();
		    	glColor3f(0.75f, 0.75f, 0.75f);
			    glTranslatef(0.0f, 1.04f, 0.0f); // ����ײ�λ��Բ������
			    glutSolidSphere(0.08f, 20, 20);
			    applyMaterial();
		    glPopMatrix();

        glPopMatrix();
    }
};

// ��
class Queen : public ChessPiece {
public:
    using ChessPiece::ChessPiece;
    
    PieceType getType() const override { return QUEEN; }
    
    void drawSimple() const override {
		// ���õ�ǰ���ӵ�id
    	glLoadName(id);

			// ����
            drawBase();
            applyMaterial();

            // ����Բ׶���ϣ�
		    glPushMatrix();
		    	glTranslatef(0.0f, -0.4f, 0.0f);
			    glRotatef(-90, 1, 0, 0);
			    glutSolidCone(0.3f, 1.4f, 20, 20); // �ײ�Y=0������Y=0.8
		    glPopMatrix();
		    
			// ����Բ׶
		    glPushMatrix();
		    	glTranslatef(0.0f, 0.95f, 0.0f);
			    glRotatef(90, 1, 0, 0);
			    glutSolidCone(0.2f, 1.0f, 20, 20); // �ײ�Y=0������Y=0.8
		    glPopMatrix();
		    
		    // ��������
		    glPushMatrix();
		    	glTranslatef(0.0f, 0.13f, 0.0f);
			    glTranslatef(0.0f, 1.0f, 0.0f);
			    glutSolidSphere(0.2f, 20, 20);
		    glPopMatrix();
	}

    void draw() const override {
        glPushMatrix();
            transformPosition();
            
            drawSimple();

			// ��ɫ�徱
			glPushMatrix();
		 		glColor3f(1.0f, 0.84f, 0.0f);
			    glTranslatef(0.0f, 0.5f, 0.0f);
			    glRotatef(-90, 1, 0, 0);
			    glutSolidCylinder(0.35f, 0.1f, 8, 2); // �߶���Y��
			    applyMaterial();
		    glPopMatrix();

			// ��ɫ�徱
		    glPushMatrix();
		 		glColor3f(0.75f, 0.75f, 0.75f);
			    glTranslatef(0.0f, 0.6f, 0.0f);
			    glRotatef(-90, 1, 0, 0);
			    glutSolidCylinder(0.3f, 0.1f, 8, 2); // �߶���Y��
			    applyMaterial();
		    glPopMatrix();

		    // �ʹ�Ȧ
		    glPushMatrix();
		    	glColor3f(1.0f, 0.84f, 0.0f);
		    	glTranslatef(0.0f, 1.27f, 0.0f);
			    glRotatef(90, 1, 0, 0);
			    glutSolidCone(0.185f, 0.5f, 20, 20); // �ײ�Y=0������Y=0.8
			    applyMaterial();
		    glPopMatrix();

		    // �ʹڼ��
		    glPushMatrix();
		    	glColor3f(1.0f, 0.84f, 0.0f);
		    	glTranslatef(0.0f, 1.01f, 0.0f);
			    for (int i = 0; i < 6; i++) {
			        glPushMatrix();
			        glRotatef(i*60, 0, 1, 0);
			        glRotatef(-60, 1, 0, 0);
			        glutSolidCone(0.1f, 0.4f, 16, 16);
			        glPopMatrix();
			    }
			    applyMaterial();
			glPopMatrix();

        glPopMatrix();
    }
};

// ��
class King : public ChessPiece {
public:
    using ChessPiece::ChessPiece;
    
    PieceType getType() const override { return KING; }
    
    void drawSimple() const override {
		// ���õ�ǰ���ӵ�id
    	glLoadName(id);

            // ����
            drawBase();
            applyMaterial();

            // ����Բ׶���ϣ�
		    glPushMatrix();
		    	glTranslatef(0.0f, -0.4f, 0.0f);
			    glRotatef(-90, 1, 0, 0);
			    glutSolidCone(0.3f, 1.4f, 20, 20); // �ײ�Y=0������Y=0.8
		    glPopMatrix();
		    
		    // ����Բ׶���£�
		    glPushMatrix();
		    	glTranslatef(0.0f, 1.1f, 0.0f);
			    glRotatef(90, 1, 0, 0);
			    glutSolidCone(0.2f, 1.0f, 20, 20); // �ײ�Y=0������Y=0.8
		    glPopMatrix();
	}

    void draw() const override {
        glPushMatrix();
            transformPosition();

			drawSimple();

			// ��ɫ�徱
			glPushMatrix();
		 		glColor3f(1.0f, 0.84f, 0.0f);
			    glTranslatef(0.0f, 0.5f, 0.0f);
			    glRotatef(-90, 1, 0, 0);
			    glutSolidCylinder(0.35f, 0.1f, 8, 2); // �߶���Y��
			    applyMaterial();
		    glPopMatrix();

			// ��ɫ�徱
		    glPushMatrix();
		 		glColor3f(0.75f, 0.75f, 0.75f);
			    glTranslatef(0.0f, 0.6f, 0.0f);
			    glRotatef(-90, 1, 0, 0);
			    glutSolidCylinder(0.3f, 0.1f, 8, 2); // �߶���Y��
				applyMaterial();
		    glPopMatrix();

			// ʮ�ּ�
			glPushMatrix();
				glColor3f(0.8f, 0.65f, 0.25f);
				glTranslatef(0.0f, 1.3f, 0.0f);
			    glScalef(0.1f, 0.4f, 0.1f);
			    glutSolidCube(1.0f); // �ײ�Y=0������Y=0.8
		    glPopMatrix();
		    glPushMatrix();
				glTranslatef(0.0f, 1.335f, 0.0f);
				glRotatef(90, 0, 1, 0);
			    glScalef(0.1f, 0.1f, 0.25f);
			    glutSolidCube(1.0f); // �ײ�Y=0������Y=0.8
			    applyMaterial();
		    glPopMatrix();

        glPopMatrix();
    }
};

// ��������
ChessPiece* createPiece(int type, float col, float hgt, float row, bool isWhite) {
	if(col <0 || col>7 || row<0 || row>7) return nullptr;
	
    switch(type) {
        case 80: case 112:
			return new Pawn(col, hgt, row, isWhite);
        case 82: case 114:
			return new Rook(col, hgt, row, isWhite);
        case 78: case 110:
			return new Knight(col, hgt, row, isWhite);
        case 66: case 98:
			return new Bishop(col, hgt, row, isWhite);
        case 81: case 113:
			return new Queen(col, hgt, row, isWhite);
        case 75: case 107:
			return new King(col, hgt, row, isWhite);
        default:
			return nullptr;
    }
}
