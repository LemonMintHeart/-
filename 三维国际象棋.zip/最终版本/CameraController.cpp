// CameraController.cpp
#define _USE_MATH_DEFINES
#include <cmath>
#include <GL/freeglut.h>
#include "CameraController.h"
#include "GameManager.h"

CameraState Camera;

void updateCameraPosition() {
    Camera.eyeX = Camera.radius * sin(Camera.theta * M_PI/180) * cos(Camera.phi * M_PI/180);
    Camera.eyeZ = Camera.radius * cos(Camera.theta * M_PI/180) * cos(Camera.phi * M_PI/180);
    Camera.eyeY = Camera.radius * sin(Camera.phi * M_PI/180);
}

void handleCameraMovement(unsigned char key, int x, int y) {
    const float rotateSpeed = 2.0f;
    const float zoomSpeed = 1.0f;
    const float minRadius = 5.0f;
    const float maxRadius = 50.0f;
    const float minPhi = 5.0f;
    const float maxPhi = 85.0f;

	switch(key) {
	    case 'W': case 'w': Camera.radius = fmax(minRadius, Camera.radius - zoomSpeed); break;
	    case 'S': case 's': Camera.radius = fmin(maxRadius, Camera.radius + zoomSpeed); break;
	    case 'A': case 'a': Camera.theta -= rotateSpeed; break;
	    case 'D': case 'd': Camera.theta += rotateSpeed; break;
	    case 'Q': case 'q': Camera.phi = fmin(maxPhi, Camera.phi + rotateSpeed); break;
	    case 'E': case 'e': Camera.phi = fmax(minPhi, Camera.phi - rotateSpeed); break;
	}
	
    updateCameraPosition();
    glutPostRedisplay();
}
