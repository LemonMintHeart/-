// GameManager.h

#pragma once
#include <string>
#include "ChessBoard.h"

class ChessSquare;
class ChessPiece;

enum Round {
	White = 1, Black = 0
};

enum State{
	SelectPiece = 1, SelectPosition = 2, ConfirmPosition = 3
};

// ��Ϸ������
class GameManager {
private:
    static State currentState;
    static Round currentRound;

public:
	static char LAYOUT[10][10]; // �Ƴ�const���η�
	static std::string winner;
	static int roundCount;
	static bool isPromoting;
	static ChessPiece* waitToDelete;
	
    // ״̬���ʽӿ�
    static void showLayout();
    static void updateLayout(int startRow, int startCol, int targetRow, int targetCol, char symbol);
    static void updateWaitToDelete(int targetCol, int targetRow);
    static void deletePiece();
    static void switchRound();
    static void setCurrentState(State newState);
    static State getCurrentState() { return currentState; }
    static Round getCurrentRound() { return currentRound; }
};

// ��ѡ���ƹ�����
class SelectionManager {
private:
    static ChessSquare* selectedSquare;
    static ChessPiece* selectedPiece;

public:
    static void selectPiece(ChessPiece* piece);
    static void selectSquare(ChessSquare* square, bool confirm);
    static void clearSelection();
    static ChessPiece* getSelectedPiece() { return selectedPiece; }
    static ChessSquare* getSelectedSquare() { return selectedSquare; }
};

void processHits(GLint hits, GLuint buffer[]);
void resetAllObject();
void onClick(int button, int state, int x, int y);
void move(ChessPiece* piece, ChessSquare* square);
bool isAccessible(ChessPiece* piece, ChessSquare* square);
bool checkPathStraight(int startCol, int startRow, int endCol, int endRow, bool isWhite);
bool checkPathDiagonal(int startCol, int startRow, int endCol, int endRow, bool isWhite);
void promotion(ChessPiece* piece);
